# Проект: Путешествие по России
# [Ссылка на проект в GitHub] (https://github.com/AndreyMazer/russian-travel-main/blob/main/russian-travel-main.zip)
### Обзор
* Интро
* Figma
* Картинки
### Данный проект задание от Яндекс Практимума, цель которого, научиться работать с макетом и делать сайт адаптивным.
**Интро**
### Данный проект рассказывает о том, что в России есть что посмотреть и не обязательносудить по новостям.
**Figma**

* [Ссылка на макет в Figma](https://www.figma.com/file/5S2WSbEFL6awjVWJ0NWL8Q/Sprint-3_-Russia-_-desktop-mobile?node-id=28503%3A0)



